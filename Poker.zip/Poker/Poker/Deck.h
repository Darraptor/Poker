#ifndef Deck_h
#define Deck_h

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <string>
#include <algorithm>
#include "Player.h"
using namespace std;


class Deck{

    public:
    
    Deck();

    //holds the suit and rank of a card
    struct Card
    {
        string currentSuit;
        int currentRank;
    };
    
    void createDeck();
    void shuffleDeck();
    
    //Test getter functions used for validating the highest-scoring hand/
    //Feeds a player's hand based on predetermined cards
    vector<Card> getMockDataOfStraightFlush();
    vector<Card> getMockDataOfFourOfAKind();
    vector<Card> getMockDataOfFullHouse();
    vector<Card> getMockDataOfFlush();
    vector<Card> getMockDataOfStraight();
    vector<Card> getMockDataOfThreeOfAKind();
    vector<Card> getMockDataOfTwoOfAKind();
    vector<Card> getMockDataOfOneOfAKind();
    
    ////////////////////////////////////////////////////////////////
    
    //Sorting functions///////////////////////
    void sortByRank(vector<Card>& playerHand);
    void sortBySuit(vector<Card>& playerHand);
    //////////////////////////////////////////
    
    void draw();
    void displayHand();
    int checkPlayerScore(vector<Card> playerHand);
    int findMaxNum(vector<Card> temp);
    
    //bool functions that determine the type of hand you have
    bool isStraightFlush(vector<Card> playerHand);
    bool isFourOfAKind(vector<Card> playerHand);
    bool isFullHouse(vector<Card> playerHand);
    bool isFlush(vector<Card> playerHand);
    bool isStraight(vector<Card> playerHand);
    bool isThreeOfAKind(vector<Card> playerHand);
    bool isTwoPairs(vector<Card> playerHand);
    bool isOnePair(vector<Card> playerHand);
    //////////////////////////////////////////////////////////
    
    
    //Setter functions for setting the player's hand
    //(Used for testing purposes)
    void setPlayer1Hand(vector<Card> samplePlayerHand);
    void setPlayer2Hand(vector<Card> samplePlayerHand);
    void setPlayer3Hand(vector<Card> samplePlayerHand);
    void setPlayer4Hand(vector<Card> samplePlayerHand);
    void setPlayer5Hand(vector<Card> samplePlayerHand);
    /////////////////////////////////////////////////
    
    
    //Getter functions for getting the player's hand
    vector<Card> getPlayer1Hand();
    vector<Card> getPlayer2Hand();
    vector<Card> getPlayer3Hand();
    vector<Card> getPlayer4Hand();
    vector<Card> getPlayer5Hand();
    /////////////////////////////////////////////////

    private:
    vector<Card> myDeck;
    vector<Card> player1Hand{5};
    vector<Card> player2Hand{5};
    vector<Card> player3Hand{5};
    vector<Card> player4Hand{5};
    vector<Card> player5Hand{5};
    enum Rank{J=11, Q, K, A};
    int ListOfFaces[13] = {2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, K, A};
    string ListOfSuit[4] = {"clubs", "diamonds", "hearts","spades"};
    
};

#endif
