#include "Player.h"


Player::Player(string tempPlayerName, int tempScore)
{
    playerName=tempPlayerName;
    playerScore=tempScore;
}

void Player::findWinner(Player player1, Player player2, Player player3, Player player4, Player player5)
{
    map<int, string> thePlayers;
    map<int, string>::iterator it;
    int temp = 0;
    
    thePlayers[player1.getScore()]=player1.getName();
    thePlayers[player2.getScore()]=player2.getName();
    thePlayers[player3.getScore()]=player3.getName();
    thePlayers[player4.getScore()]=player4.getName();
    thePlayers[player5.getScore()]=player5.getName();
    
    for(it=thePlayers.begin(); it!=thePlayers.end();it++)
    {
        if(it->first>temp)
        {
            temp=it->first;
        }
    }
    
    cout<<endl;
    
    switch (temp) {
        case 9000:
            cout<<thePlayers.find(temp)->second<<" has won with a straight flush!"<<endl;
            break;
        case 8000:
            cout<<thePlayers.find(temp)->second<<" has won with a four of a kind!"<<endl;
            break;
        case 7000:
            cout<<thePlayers.find(temp)->second<<" has won with a full house!"<<endl;
            break;
        case 6000:
            cout<<thePlayers.find(temp)->second<<" has won with a flush!"<<endl;
            break;
        case 5000:
            cout<<thePlayers.find(temp)->second<<" has won with a straight!"<<endl;
            break;
        case 4000:
            cout<<thePlayers.find(temp)->second<<" has won with a three of a kind!"<<endl;
            break;
        case 3000:
            cout<<thePlayers.find(temp)->second<<" has won with two pairs!"<<endl;
            break;
        case 2000:
            cout<<thePlayers.find(temp)->second<<" has won with a pair!"<<endl;
            break;
        default:
            cout<<thePlayers.find(temp)->second<<" has won with a "<<temp<<" as a high card"<<endl;
            break;
    }
}

string Player::getName()
{
    return playerName;
}

int Player::getScore()
{
    return playerScore;
}

