#include "Deck.h"

Deck::Deck()
{
    
}

void Deck::createDeck()
{
    Card c;
    
    //Assigns each card inside the deck a face and value
    for (int i = 0; i < 52; i++) {
        c.currentRank = ListOfFaces[i % 13];
        c.currentSuit = ListOfSuit[i % 4];
        myDeck.push_back(c);
    }
}
void Deck::shuffleDeck()
{
    Card temp;
    int randomIndex = 0;
    
    for (int i = 0; i < 52; i++) {
        randomIndex = rand() % 52;
        temp = myDeck[i];
        myDeck[i] = myDeck[randomIndex];
        myDeck[randomIndex] = temp;
    }
}
void Deck::draw()
{
    for (int i = 0; i < 25; i++)
    {
        //Draw 5 cards from the Deck for Player 1
        if (i < 5)
        {
            player1Hand[i].currentRank = myDeck[i].currentRank;
            player1Hand[i].currentSuit = myDeck[i].currentSuit;
        }
        
        //Draw 5 cards from the Deck for Player 2
        else if (i < 10)
        {
            player2Hand[i-5].currentRank = myDeck[i].currentRank;
            player2Hand[i-5].currentSuit = myDeck[i].currentSuit;
        }
        
        //Draw 5 cards from the Deck for Player 3
        else if (i < 15)
        {
            player3Hand[i-10].currentRank = myDeck[i].currentRank;
            player3Hand[i-10].currentSuit = myDeck[i].currentSuit;
        }
        
        //Draw 5 cards from the Deck for Player 4
        else if (i < 20)
        {
            player4Hand[i-15].currentRank = myDeck[i].currentRank;
            player4Hand[i-15].currentSuit = myDeck[i].currentSuit;
        }
        
        else if (i < 25)
        {
            player5Hand[i-20].currentRank = myDeck[i].currentRank;
            player5Hand[i-20].currentSuit = myDeck[i].currentSuit;
        }
    }
}



void Deck::displayHand()
{
    
    cout << "----------------------------------------" << endl;
    cout << "Player one has the following in his hand:" << endl;
    for(int i=0;i<5;i++)
    {
        if(player1Hand[i].currentRank<11)
        {
            cout << player1Hand[i].currentRank << " of " << player1Hand[i].currentSuit << endl;
        }
        
        else
        {
            switch (player1Hand[i].currentRank) {
                case 11:
                    cout << "J" << " of " << player1Hand[i].currentSuit << endl;
                    break;
                case 12:
                    cout << "Q" << " of " << player1Hand[i].currentSuit << endl;
                    break;
                case 13:
                    cout << "K" << " of " << player1Hand[i].currentSuit << endl;
                    break;
                case 14:
                    cout << "A" << " of " << player1Hand[i].currentSuit << endl;
                    break;
            }
        }
    }
    
    cout << "----------------------------------------" << endl;
    cout << "Player two has the following in his hand:" << endl;
    for(int i=0;i<5;i++)
    {
        if(player2Hand[i].currentRank<11)
        {
            cout << player2Hand[i].currentRank << " of " << player2Hand[i].currentSuit << endl;
        }
        
        else
        {
            switch (player2Hand[i].currentRank) {
                case 11:
                    cout << "J" << " of " << player2Hand[i].currentSuit << endl;
                    break;
                case 12:
                    cout << "Q" << " of " << player2Hand[i].currentSuit << endl;
                    break;
                case 13:
                    cout << "K" << " of " << player2Hand[i].currentSuit << endl;
                    break;
                case 14:
                    cout << "A" << " of " << player2Hand[i].currentSuit << endl;
                    break;
            }
        }

    }
    
    cout << "----------------------------------------" << endl;
    cout << "Player three has the following in his hand:" << endl;
    for(int i=0;i<5;i++)
    {
        if(player3Hand[i].currentRank<11)
        {
            cout << player3Hand[i].currentRank << " of " << player3Hand[i].currentSuit << endl;
        }
        
        else
        {
            switch (player3Hand[i].currentRank) {
                case 11:
                    cout << "J" << " of " << player3Hand[i].currentSuit << endl;
                    break;
                case 12:
                    cout << "Q" << " of " << player3Hand[i].currentSuit << endl;
                    break;
                case 13:
                    cout << "K" << " of " << player3Hand[i].currentSuit << endl;
                    break;
                case 14:
                    cout << "A" << " of " << player3Hand[i].currentSuit << endl;
                    break;
            }
        }

    }
    
    cout << "----------------------------------------" << endl;
    cout << "Player four has the following in his hand:" << endl;
    for(int i=0;i<5;i++)
    {
        if(player4Hand[i].currentRank<11)
        {
            cout << player4Hand[i].currentRank << " of " << player4Hand[i].currentSuit << endl;
        }
        
        else
        {
            switch (player4Hand[i].currentRank) {
                case 11:
                    cout << "J" << " of " << player4Hand[i].currentSuit << endl;
                    break;
                case 12:
                    cout << "Q" << " of " << player4Hand[i].currentSuit << endl;
                    break;
                case 13:
                    cout << "K" << " of " << player4Hand[i].currentSuit << endl;
                    break;
                case 14:
                    cout << "A" << " of " << player4Hand[i].currentSuit << endl;
                    break;
            }
        }

    }
    
    cout << "----------------------------------------" << endl;
    cout << "Player five has the following in his hand:" << endl;
    for(int i=0;i<5;i++)
    {
        if(player5Hand[i].currentRank<11)
        {
            cout << player5Hand[i].currentRank << " of " << player5Hand[i].currentSuit << endl;
        }
        
        else
        {
            switch (player5Hand[i].currentRank) {
                case 11:
                    cout << "J" << " of " << player5Hand[i].currentSuit << endl;
                    break;
                case 12:
                    cout << "Q" << " of " << player5Hand[i].currentSuit << endl;
                    break;
                case 13:
                    cout << "K" << " of " << player5Hand[i].currentSuit << endl;
                    break;
                case 14:
                    cout << "A" << " of " << player5Hand[i].currentSuit << endl;
                    break;
            }
        }

    }
}

void Deck::sortByRank(vector<Card>& playerHand)
{
    int min;
    
    for(int i=0; i<5; i++)
    {
        min = i;
        
        for(int j=i+1; j<5; j++)
        {
            if(playerHand[j].currentRank < playerHand[min].currentRank)
            {
                min = j;
            }
        }
        
        Card temp = playerHand[i];
        playerHand[i]=playerHand[min];
        playerHand[min]=temp;
    }
}
void Deck::sortBySuit(vector<Card>& playerHand)
{
    int min;
    
    for(int i=0; i<5; i++)
    {
        min = i;
        
        for(int j=i+1; j<5; j++)
        {
            if(playerHand[j].currentSuit < playerHand[min].currentSuit)
            {
                min = j;
            }
        }
        
        Card temp = playerHand[i];
        playerHand[i]=playerHand[min];
        playerHand[min]=temp;
    }
}

int Deck::checkPlayerScore(vector<Card> playerHand)
{
   if(isStraightFlush(playerHand))
   {
       return 9000;
   }
    
   else if(isFourOfAKind(playerHand))
   {
       return 8000;
   }
    
   else if(isFullHouse(playerHand))
   {
       return 7000;
   }
    
   else if(isFlush(playerHand))
   {
       return 6000;
   }
    
   else if(isStraight(playerHand))
   {
       return 5000;
   }
    
   else if(isThreeOfAKind(playerHand))
   {
       return 4000;
   }
    
   else if(isTwoPairs(playerHand))
   {
       return 3000;
   }
    
   else if(isOnePair(playerHand))
   {
       return 2000;
   }
   
   //High Card case
   else
   {
       return findMaxNum(playerHand);
   }
}

bool Deck::isStraightFlush(vector<Card> playerHand)
{
    bool caseWithAce1, caseWithAce2;
    int myRank=0;
    
    sortByRank(playerHand);
    
    //Case scenario where there might be a straight with an ace
    if(playerHand[4].currentRank == 14)
    {
        caseWithAce1 = playerHand[0].currentRank == 2 && playerHand[1].currentRank == 3 &&
        playerHand[2].currentRank == 4 && playerHand[3].currentRank == 5 ;
        
        caseWithAce2 = playerHand[0].currentRank == 10 && playerHand[1].currentRank == 11 &&
        playerHand[2].currentRank == 12 && playerHand[3].currentRank == 13 ;
        
        return (caseWithAce1 || caseWithAce2);
    }
    
    //Case scenario where there might be a straight with without an ace
    else
    {
        myRank = playerHand[0].currentRank + 1;
        
        for(int i=1; i<5; i++)
        {
            if(playerHand[i].currentRank != myRank)
            {
                return false;
            }
            
            ++myRank;
        }
        
        return true;
    }
}
bool Deck::isFourOfAKind(vector<Card> playerHand)
{
    bool case1, case2;
    
    sortByRank(playerHand);
    
    //case1 checks if the first card has a different rank from the remaining four cards
    case1 = playerHand[0].currentRank == playerHand[1].currentRank &&
    playerHand[1].currentRank== playerHand[2].currentRank &&
    playerHand[2].currentRank == playerHand[3].currentRank;
    
    //case2 checks if the first four cards have the same rank while the last card has a different one
    case2 = playerHand[1].currentRank == playerHand[2].currentRank &&
    playerHand[2].currentRank == playerHand[3].currentRank &&
    playerHand[3].currentRank == playerHand[4].currentRank;
    
    return( case1 || case2 );
}
bool Deck::isFullHouse(vector<Card> playerHand)
{
    bool case1, case2;
    
    sortByRank(playerHand);
    
    //Checks for a hand with the first three cards have the same rank and the last two cards
    //have the same rank that is different from the first three
    case1 = playerHand[0].currentRank == playerHand[1].currentRank &&
    playerHand[1].currentRank == playerHand[2].currentRank &&
    playerHand[3].currentRank == playerHand[4].currentRank;
    
    //Checks for a hand with the first two cards have the same rank and the last three cards
    //have the same rank that is different from the first two
    case2 = playerHand[0].currentRank == playerHand[1].currentRank &&
    playerHand[2].currentRank == playerHand[3].currentRank &&
    playerHand[3].currentRank == playerHand[4].currentRank;
    
    return( case1 || case2 );
}

bool Deck::isFlush(vector<Card> playerHand)
{
    sortBySuit(playerHand);
    
    return (playerHand[0].currentSuit == playerHand[4].currentSuit);
}

bool Deck::isStraight(vector<Card> playerHand)
{
    int myRank;
    bool case1, case2;
    
    sortByRank(playerHand);
   
    //Check for a possible straight with an ace
    if(playerHand[4].currentRank == 14)
    {
        
        case1 = (playerHand[0].currentRank == 2 && playerHand[1].currentRank == 3 && playerHand[2].currentRank == 4 && playerHand[3].currentRank == 5);
        case2 = (playerHand[0].currentRank == 10 && playerHand[1].currentRank == 11 && playerHand[2].currentRank == 12 && playerHand[3].currentRank == 13);
        
        return (case1 || case2);
    }
    
    //Check for a possible straight without an ace
    else
    {
        myRank = playerHand[0].currentRank + 1;
        
        for (int i = 1; i < 5; i++)
        {
            if (playerHand[i].currentRank != myRank )
            {
                return false;
            }
            myRank++;
        }
        
        return true;
    }
}
bool Deck::isThreeOfAKind(vector<Card> playerHand)
{
    bool case1, case2, case3;
    
    //Hand can't be Three of a kind if its either four of a kind or a full house
    if(isFourOfAKind(playerHand) || isFullHouse(playerHand))
    {
        return false;
    }
    
    sortByRank(playerHand);
    
    //Checks if the first three cards in the hand have the same rank and the last two have entirely different ranks from the
    //first three
    case1 = (playerHand[0].currentRank == playerHand[1].currentRank && playerHand[1].currentRank == playerHand[2].currentRank);
    
    //Checks if the first card and the last card in the hand have entirely different ranks from the three cards in the middle that should
    //all have the same rank
    case2 = (playerHand[1].currentRank == playerHand[2].currentRank && playerHand[2].currentRank == playerHand[3].currentRank);
    
    //Checks if the first two cards in the hand have entirely different ranks from the last three cards which all have the same rank
    case3 = (playerHand[2].currentRank == playerHand[3].currentRank && playerHand[3].currentRank == playerHand[4].currentRank);
    
    return (case1 || case2 || case3);
}
bool Deck::isTwoPairs(vector<Card> playerHand)
{
    bool case1, case2, case3;
    
    if ( isFourOfAKind(playerHand) || isFullHouse(playerHand) || isThreeOfAKind(playerHand))
    {
        return false;
    }
    
    sortByRank(playerHand);
    
    //case 1 is looking for a hand with the first card being a lower different rank from the other two  different pairs matching rank card
    case1 = (playerHand[0].currentRank == playerHand[1].currentRank && playerHand[2].currentRank == playerHand[3].currentRank);
    
    //case 2 is looking for a hand with the first card having the same rank as the last card with the middle card bein
    case2 = (playerHand[0].currentRank == playerHand[1].currentRank && playerHand[3].currentRank == playerHand[4].currentRank);
    
    case3 = (playerHand[1].currentRank == playerHand[2].currentRank && playerHand[3].currentRank == playerHand[4].currentRank);
    
    return (case1 || case2 || case3);
}
bool Deck::isOnePair(vector<Card> playerHand)
{
    bool case1, case2, case3, case4;
    
    if ( isFourOfAKind(playerHand) || isFullHouse(playerHand) || isThreeOfAKind(playerHand) || isTwoPairs(playerHand))
    {
        return false;
    }
    
    sortByRank(playerHand);
    
    case1 = playerHand[0].currentRank == playerHand[1].currentRank;
    
    case2 = playerHand[1].currentRank == playerHand[2].currentRank;
    
    case3 = playerHand[2].currentRank == playerHand[3].currentRank;
    
    case4 = playerHand[3].currentRank == playerHand[4].currentRank;
    
    return(case1 || case2 || case3 || case4);
    
}

int Deck::findMaxNum(vector<Card> tempVec)
{
    int tempNum = 0;
    
    for(int i=0;i<5;i++)
    {
        if(tempVec[i].currentRank>tempNum)
        {
            tempNum=tempVec[i].currentRank;
        }
    }
    
    return tempNum;
}

vector<Deck::Card> Deck::getPlayer1Hand()
{
    return player1Hand;
}
vector<Deck::Card> Deck::getPlayer2Hand()
{
    return player2Hand;
}
vector<Deck::Card> Deck::getPlayer3Hand()
{
    return player3Hand;
}
vector<Deck::Card> Deck::getPlayer4Hand()
{
    return player4Hand;
}
vector<Deck::Card> Deck::getPlayer5Hand()
{
    return player5Hand;
}

vector<Deck::Card> Deck::getMockDataOfStraightFlush()
{
    vector<Deck::Card> MyStraightFlushHand{5};
    
    for(int i=0;i<5;i++)
    {
        MyStraightFlushHand[i].currentRank=8-i;
        MyStraightFlushHand[i].currentSuit="clubs";
    }
    
    return MyStraightFlushHand;
    
    
}
vector<Deck::Card> Deck::getMockDataOfFourOfAKind()
{
    vector<Deck::Card> MyFourOfAKindHand{5};
    
    for(int i=0;i<4;i++)
    {
        MyFourOfAKindHand[i].currentRank=11;
        
        switch (i) {
            case 0:
                MyFourOfAKindHand[0].currentSuit="hearts";
                break;
            case 1:
                MyFourOfAKindHand[1].currentSuit="diamonds";
                break;
            case 2:
                MyFourOfAKindHand[2].currentSuit="clubs";
                break;
            case 3:
                MyFourOfAKindHand[3].currentSuit="spades";
                break;
        }
    }
    
    MyFourOfAKindHand[4].currentRank=7;
    MyFourOfAKindHand[4].currentSuit="diamonds";
    
    return MyFourOfAKindHand;
}
vector<Deck::Card> Deck::getMockDataOfFullHouse()
{
    vector<Deck::Card> MyFullHouseHand{5};
    
    for(int i=0;i<5;i++)
    {
        if(i<3)
        {
            MyFullHouseHand[i].currentRank=10;
        }
        
        else
        {
            MyFullHouseHand[i].currentRank=9;
        }
    }
    
    MyFullHouseHand[0].currentSuit="hearts";
    MyFullHouseHand[1].currentSuit="diamonds";
    MyFullHouseHand[2].currentSuit="spades";
    MyFullHouseHand[3].currentSuit="clubs";
    MyFullHouseHand[4].currentSuit="diamonds";
    
    return MyFullHouseHand;
}
vector<Deck::Card> Deck::getMockDataOfFlush()
{
    vector<Deck::Card> MyFlushHand{5};
    
    for(int i=0; i<5; i++)
    {
        MyFlushHand[i].currentSuit="spades";
    }
    
    MyFlushHand[0].currentRank=4;
    MyFlushHand[1].currentRank=11;
    MyFlushHand[2].currentRank=8;
    MyFlushHand[3].currentRank=2;
    MyFlushHand[4].currentRank=9;
    
    return MyFlushHand;
}
vector<Deck::Card> Deck::getMockDataOfStraight()
{
    vector<Deck::Card> MyStraightHand{5};
    
    for(int i=0; i<5; i++)
    {
        MyStraightHand[i].currentRank=9-i;
    }
    
    MyStraightHand[0].currentSuit="spades";
    MyStraightHand[1].currentSuit="diamonds";
    MyStraightHand[2].currentSuit="spades";
    MyStraightHand[3].currentSuit="diamonds";
    MyStraightHand[4].currentSuit="hearts";
    
    return MyStraightHand;
    
}
vector<Deck::Card> Deck::getMockDataOfThreeOfAKind()
{
    vector<Deck::Card> MyThreeOfAKindHand{5};
    
    for(int i=0; i<3; i++)
    {
        MyThreeOfAKindHand[i].currentRank=7;
    }
    
    MyThreeOfAKindHand[3].currentRank=13;
    MyThreeOfAKindHand[4].currentRank=3;
    
    MyThreeOfAKindHand[0].currentSuit="clubs";
    MyThreeOfAKindHand[1].currentSuit="diamonds";
    MyThreeOfAKindHand[2].currentSuit="spades";
    MyThreeOfAKindHand[3].currentSuit="clubs";
    MyThreeOfAKindHand[4].currentSuit="diamonds";
    
    return MyThreeOfAKindHand;
}
vector<Deck::Card> Deck::getMockDataOfTwoOfAKind()
{
    vector<Deck::Card> MyTwoOfAKindHand{5};
    
    for(int i=0; i<4; i++)
    {
        if(i>2)
        {
            MyTwoOfAKindHand[i].currentRank=4;
        }
        
        else
        {
            MyTwoOfAKindHand[i].currentRank=3;
        }
    }
    
    MyTwoOfAKindHand[4].currentRank=12;
    
    MyTwoOfAKindHand[0].currentSuit="clubs";
    MyTwoOfAKindHand[1].currentSuit="spades";
    MyTwoOfAKindHand[2].currentSuit="clubs";
    MyTwoOfAKindHand[3].currentSuit="diamonds";
    MyTwoOfAKindHand[3].currentSuit="clubs";
    
    return MyTwoOfAKindHand;
}
vector<Deck::Card> Deck::getMockDataOfOneOfAKind()
{
    vector<Deck::Card> MyOneOfAKindHand{5};
    
    for(int i=0; i<2; i++)
    {
        MyOneOfAKindHand[i].currentRank=6;
    }
    
    MyOneOfAKindHand[2].currentRank=8;
    MyOneOfAKindHand[3].currentRank=4;
    MyOneOfAKindHand[4].currentRank=7;
    
    MyOneOfAKindHand[0].currentSuit="hearts";
    MyOneOfAKindHand[1].currentSuit="diamonds";
    MyOneOfAKindHand[2].currentSuit="clubs";
    MyOneOfAKindHand[3].currentSuit="spades";
    MyOneOfAKindHand[4].currentSuit="hearts";
    
    return MyOneOfAKindHand;
}

void Deck::setPlayer1Hand(vector<Card> samplePlayerHand)
{
    player1Hand=samplePlayerHand;
}
void Deck::setPlayer2Hand(vector<Card> samplePlayerHand)
{
    player2Hand=samplePlayerHand;
}
void Deck::setPlayer3Hand(vector<Card> samplePlayerHand)
{
    player3Hand=samplePlayerHand;
}
void Deck::setPlayer4Hand(vector<Card> samplePlayerHand)
{
    player4Hand=samplePlayerHand;
}
void Deck::setPlayer5Hand(vector<Card> samplePlayerHand)
{
    player5Hand=samplePlayerHand;
}

