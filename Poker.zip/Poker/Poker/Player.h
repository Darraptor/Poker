#ifndef Player_h
#define Player_h

#include <iostream>
#include <string>
#include <map>
using namespace std;

class Player
{
public:
    Player(string tempPlayerName, int tempScore);
    void setScore(int theScore);
    int getScore();
    string getName();
    void findWinner(Player player1, Player player2, Player player3, Player player4, Player player5);
    
private:
    int playerScore;
    string playerName;
};


#endif 
