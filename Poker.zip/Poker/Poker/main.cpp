#include "Deck.h"


int main(int argc, const char * argv[])
{
    Deck theDeck;
    
    srand (unsigned(time(0)));

    theDeck.createDeck();
    theDeck.shuffleDeck();
    theDeck.draw();
    theDeck.displayHand();
    
    
    Player player1("player1",theDeck.checkPlayerScore(theDeck.getPlayer1Hand())),
    player2("player2",theDeck.checkPlayerScore(theDeck.getPlayer2Hand())),
    player3("player3",theDeck.checkPlayerScore(theDeck.getPlayer3Hand())),
    player4("player4",theDeck.checkPlayerScore(theDeck.getPlayer4Hand())),
    player5("player5",theDeck.checkPlayerScore(theDeck.getPlayer5Hand()));
    
    player5.findWinner(player1, player2, player3, player4, player5);
            

    return 0;
}
